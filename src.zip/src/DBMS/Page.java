
package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Page implements Serializable {

	public ArrayList<String[]> records;
	private int pageNumber;

	public Page(ArrayList<String[]> records, int pageNumber) {
		this.records = (records != null) ? records : new ArrayList<>();
		this.pageNumber = pageNumber;
	}

	public boolean AvailableSpace() {
		return records.size() < DBApp.dataPageSize;
	}

	public void insertInPage(String[] record) {
		if (AvailableSpace()) {
			records.add(record);
		} else {
			System.out.println("The page you're trying to insert in is currently full.");
		}
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public ArrayList<String[]> getRecords() {
		return records;
	}
}

