package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Table implements Serializable {

	private String table1;
	private String[] coloumns;
	private ArrayList<Page> pages;
	private ArrayList<String> traceLog; 

	public Table(String table1, String[] coloumns) {
		this.table1 = table1;
		this.coloumns = coloumns != null ? coloumns : new String[0];
		this.pages = new ArrayList<>();
		this.traceLog = new ArrayList<>();
	}

	public Table(String table1, String[] coloumns, ArrayList<Page> pages) {
		this.table1 = table1;
		this.coloumns = coloumns != null ? coloumns : new String[0];
		this.pages = pages != null ? pages : new ArrayList<>();
		this.traceLog = new ArrayList<>();
	}

	public String getTable1() {
		return table1;
	}

	public String[] getColoumns() {
		return coloumns;
	}

	public ArrayList<Page> getPages() {
		if (pages == null) {
			pages = new ArrayList<>();
		}
		return pages;
	}

	public int getPageCount() {
		return pages.size();
	}

	public void logOperation(String message) {
		if (traceLog == null) {
			traceLog = new ArrayList<>();
		}
		traceLog.add(message);
	}

	public ArrayList<String> getTraceLog() {
		return traceLog != null ? traceLog : new ArrayList<>();
	}

	public String getLastTrace() {
		if (traceLog == null || traceLog.isEmpty()) {
			return "No trace available.";
		}
		return traceLog.get(traceLog.size() - 1);
	}

	public void setPages(ArrayList<Page> pages) {
		this.pages = pages;
	}
}
