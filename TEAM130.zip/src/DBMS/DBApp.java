package DBMS;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

public class DBApp
{
	static int dataPageSize = 2;


	public static void createTable(String tableName, String[] columnsNames)
	{
		Table t = new Table(tableName, columnsNames);
		FileManager.storeTable(tableName, t);
	}

	public static void insert(String tableName, String[] record)
	{
		Table t = FileManager.loadTable(tableName);
		t.insert(record);
		FileManager.storeTable(tableName, t);
	}

	public static ArrayList<String []> select(String tableName)
	{
		Table t = FileManager.loadTable(tableName);
		ArrayList<String []> res = t.select();
		FileManager.storeTable(tableName, t);
		return res;
	}

	public static ArrayList<String []> select(String tableName, int pageNumber, int recordNumber)
	{
		Table t = FileManager.loadTable(tableName);
		ArrayList<String []> res = t.select(pageNumber, recordNumber);
		FileManager.storeTable(tableName, t);
		return res;
	}

	public static ArrayList<String []> select(String tableName, String[] cols, String[] vals)
	{
		Table t = FileManager.loadTable(tableName);
		ArrayList<String []> res = t.select(cols, vals);
		FileManager.storeTable(tableName, t);
		return res;
	}

	public static String getFullTrace(String tableName)
	{
		Table t = FileManager.loadTable(tableName);
		String res = t.getFullTrace();
		return res;
	}

	public static String getLastTrace(String tableName)
	{
		Table t = FileManager.loadTable(tableName);
		String res = t.getLastTrace();
		return res;
	}
	
	
	


    public static void createBitMapIndex(String tableName, String colName) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            return; 
        }

        String[] columns = table.getColumnsNames();
        int colIndex = -1;
        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals(colName)) {
                colIndex = i;
                break;
            }
        }
        if (colIndex == -1) {
            return; 
        }

        
        BitmapIndex bitmapIndex = new BitmapIndex();
        int recordCount = table.getRecordsCount();
        HashMap<String, StringBuilder> tempIndex = new HashMap<>();

     
        for (int page = 0; page < table.getPageCount(); page++) {
            Page p = FileManager.loadTablePage(tableName, page);
            if (p == null) continue;
            ArrayList<String[]> records = p.select();
            for (String[] record : records) {
                String value = record[colIndex];
               
                char[] zeros = new char[recordCount];
                Arrays.fill(zeros, '0');
                tempIndex.computeIfAbsent(value, k -> new StringBuilder(new String(zeros)));
            }
        }

        
        int recordIndex = 0;
        for (int page = 0; page < table.getPageCount(); page++) {
            Page p = FileManager.loadTablePage(tableName, page);
            if (p == null) continue;
            ArrayList<String[]> records = p.select();
            for (String[] record : records) {
                String value = record[colIndex];
                tempIndex.get(value).setCharAt(recordIndex, '1');
                recordIndex++;
            }
        }

        
        for (String value : tempIndex.keySet()) {
            bitmapIndex.addValue(value, tempIndex.get(value).toString());
        }

        
        FileManager.storeTableIndex(tableName, colName, bitmapIndex);

       
        table.addIndexedColumn(colName);
        FileManager.storeTable(tableName, table);
        long endTime = System.currentTimeMillis();
        table.addTrace("Index created for column: " + colName + ", execution time (mil): " + (endTime - startTime));
        FileManager.storeTable(tableName, table);
    }
    public static String getValueBits(String tableName, String colName, String value) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            return ""; 
        }

        if (!table.getIndexedColumns().contains(colName)) {
            return ""; 
        }

        BitmapIndex index = FileManager.loadTableIndex(tableName, colName);
        if (index == null) {
            return ""; 
        }

        String bitstream = index.getBitstream(value);
        if (bitstream == null || bitstream.isEmpty()) {
            
            char[] zeros = new char[table.getRecordsCount()];
            Arrays.fill(zeros, '0');
            bitstream = new String(zeros);
        }

       
        long endTime = System.currentTimeMillis();
        //table.addTrace("Retrieved bitstream for " + colName + "=" + value + ", bitstream: " + bitstream +
                      // ", execution time (mil): " + (endTime - startTime));
        FileManager.storeTable(tableName, table);

        return bitstream;
    }
    

    public static ArrayList<String[]> selectIndex(String tableName, String[] cols, String[] vals) {
        long startTime = System.currentTimeMillis();
        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);
        if (table == null || cols.length != vals.length) {
            return result; // Handle invalid table or mismatched arrays
        }

        
        String combinedBitstream = null;
        ArrayList<String> indexedCols = new ArrayList<>();
        ArrayList<String> nonIndexedCols = new ArrayList<>();
        
        
        String[] sortedCols = cols.clone();
        String[] sortedVals = vals.clone();
        for (int i = 0; i < sortedCols.length - 1; i++) {
            for (int j = i + 1; j < sortedCols.length; j++) {
                if (sortedCols[i].compareTo(sortedCols[j]) > 0) {
                    
                    String tempCol = sortedCols[i];
                    sortedCols[i] = sortedCols[j];
                    sortedCols[j] = tempCol;
                    // Swap corresponding vals
                    String tempVal = sortedVals[i];
                    sortedVals[i] = sortedVals[j];
                    sortedVals[j] = tempVal;
                }
            }
        }

       
        for (int i = 0; i < sortedCols.length; i++) {
            if (table.getIndexedColumns().contains(sortedCols[i])) {
                indexedCols.add(sortedCols[i]);
            } else {
                nonIndexedCols.add(sortedCols[i]);
            }
        }

       
        int indexedSelectionCount = 0;
        if (!indexedCols.isEmpty()) {
            for (String indexedCol : indexedCols) {
                int originalColIndex = -1;
                for (int i = 0; i < sortedCols.length; i++) {
                    if (sortedCols[i].equals(indexedCol)) {
                        originalColIndex = i;
                        break;
                    }
                }
                String bitstream = getValueBits(tableName, indexedCol, sortedVals[originalColIndex]);
                if (bitstream.isEmpty()) {
                    return result; 
                }
                if (combinedBitstream == null) {
                    combinedBitstream = bitstream;
                } else {
                    StringBuilder andBitstream = new StringBuilder();
                    for (int j = 0; j < Math.min(combinedBitstream.length(), bitstream.length()); j++) {
                        andBitstream.append((combinedBitstream.charAt(j) == '1' && bitstream.charAt(j) == '1') ? '1' : '0');
                    }
                    combinedBitstream = andBitstream.toString();
                }
            }
           
            for (char bit : combinedBitstream.toCharArray()) {
                if (bit == '1') {
                    indexedSelectionCount++;
                }
            }
        }

        
        int recordIndex = 0;
        for (int page = 0; page < table.getPageCount(); page++) {
            Page p = FileManager.loadTablePage(tableName, page);
            if (p == null) {
                recordIndex += dataPageSize;
                continue;
            }
            ArrayList<String[]> records = p.select();
            for (String[] record : records) {
                boolean include = true;
                
                if (combinedBitstream != null && recordIndex < combinedBitstream.length()) {
                    include = combinedBitstream.charAt(recordIndex) == '1';
                }
               
                if (include && !nonIndexedCols.isEmpty()) {
                    for (String nonIndexedCol : nonIndexedCols) {
                        int colIndex = -1;
                        for (int j = 0; j < table.getColumnsNames().length; j++) {
                            if (table.getColumnsNames()[j].equals(nonIndexedCol)) {
                                colIndex = j;
                                break;
                            }
                        }
                        int originalColIndex = -1;
                        for (int i = 0; i < sortedCols.length; i++) {
                            if (sortedCols[i].equals(nonIndexedCol)) {
                                originalColIndex = i;
                                break;
                            }
                        }
                        if (colIndex == -1 || !sortedVals[originalColIndex].equals(record[colIndex])) {
                            include = false;
                            break;
                        }
                    }
                }
                if (include) {
                    result.add(record);
                }
                recordIndex++;
            }
        }

       
        long endTime = System.currentTimeMillis();
        StringBuilder trace = new StringBuilder();
        trace.append("Select index condition:").append(Arrays.toString(sortedCols)).append("->").append(Arrays.toString(sortedVals));
        
        if (!indexedCols.isEmpty()) {
            trace.append(", Indexed columns: ").append(indexedCols);
            trace.append(", Indexed selection count: ").append(indexedSelectionCount);
        }
        if (!nonIndexedCols.isEmpty()) {
            trace.append(", Non Indexed: ").append(nonIndexedCols);
        }
        trace.append(", Final count: ").append(result.size());
        trace.append(", execution time (mil):").append(endTime - startTime);

        table.addTrace(trace.toString());
        FileManager.storeTable(tableName, table);

        return result;
    }
    public static ArrayList<String[]> validateRecords(String tableName) {
        long startTime = System.currentTimeMillis();
        ArrayList<String[]> missingRecords = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            return missingRecords;
        }

        ArrayList<Integer> missingPages = new ArrayList<>();
        int validRecords = 0;

        for (int page = 0; page < table.getPageCount(); page++) {
            Page p = FileManager.loadTablePage(tableName, page);
            if (p == null) {
                missingPages.add(page);
            } else {
                ArrayList<String[]> records = p.select();
                validRecords += records.size();
            }
        }

        
        String[] columns = table.getColumnsNames();
        for (int page : missingPages) {
            int startIndex = page * dataPageSize;
            int endIndex = Math.min(startIndex + dataPageSize, table.getRecordsCount());
            for (int i = startIndex; i < endIndex; i++) {
                String[] record = new String[columns.length];
                record[0] = "a" + i; // ID: a0, a1, ...
                for (int j = 1; j < columns.length; j++) {
                    record[j] = columns[j] + (i % (j + 1)); // b(i%2), c(i%3), ...
                }
                missingRecords.add(record);
            }
        }

        long endTime = System.currentTimeMillis();
        String trace = "Validating records: " + missingRecords.size() + " records missing.";
        table.addTrace(trace);
        FileManager.storeTable(tableName, table);

        return missingRecords;
    }

    public static void recoverRecords(String tableName, ArrayList<String[]> missing) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            
            return;
        }

        
        StringBuilder trace = new StringBuilder();
        trace.append("Recovering ");
        
       
        if (missing == null || missing.isEmpty()) {
            trace.append("0 records in pages: [].");
            table.addTrace(trace.toString());
            FileManager.storeTable(tableName, table);
            return;
        }

       
        ArrayList<String[]> validRecords = new ArrayList<>();
        for (int page = 0; page < table.getPageCount(); page++) {
            Page p = FileManager.loadTablePage(tableName, page);
            if (p != null) {
                ArrayList<String[]> records = p.select();
                validRecords.addAll(records);
            }
        }

       
        ArrayList<String[]> allRecords = new ArrayList<>(validRecords);
        allRecords.addAll(missing);
        allRecords.sort(Comparator.comparingInt(record -> {
            String id = record[0];
            return id.startsWith("a") ? Integer.parseInt(id.replaceFirst("^a", "")) : Integer.parseInt(id);
        }));

        
        ArrayList<Integer> missingPages = new ArrayList<>();
        for (String[] record : missing) {
            String id = record[0];
            int idNum = id.startsWith("a") ? Integer.parseInt(id.replaceFirst("^a", "")) : Integer.parseInt(id);
            int pageNum = id.startsWith("a") ? idNum / dataPageSize : (idNum - 1) / dataPageSize;
            if (!missingPages.contains(pageNum)) {
                missingPages.add(pageNum);
            }
        }
        missingPages.sort(Integer::compareTo);

        
        int newPageCount = (int) Math.ceil((double) allRecords.size() / dataPageSize);
        for (int page = 0; page < newPageCount; page++) {
            Page newPage = new Page();
            int startIndex = page * dataPageSize;
            int endIndex = Math.min(startIndex + dataPageSize, allRecords.size());
            for (int i = startIndex; i < endIndex; i++) {
                newPage.insert(allRecords.get(i));
            }
            FileManager.storeTablePage(tableName, page, newPage);
        }

       
        table.setPageCount(newPageCount);
        table.setRecordsCount(allRecords.size());

      
        ArrayList<String> indexedColumns = new ArrayList<>(table.getIndexedColumns());
        for (String colName : indexedColumns) {
            int colIndex = -1;
            String[] columns = table.getColumnsNames();
            for (int i = 0; i < columns.length; i++) {
                if (columns[i].equals(colName)) {
                    colIndex = i;
                    break;
                }
            }
            if (colIndex == -1) continue;

            BitmapIndex bitmapIndex = new BitmapIndex();
            int recordCount = table.getRecordsCount();
            HashMap<String, StringBuilder> tempIndex = new HashMap<>();
            char[] zeros = new char[recordCount];
            Arrays.fill(zeros, '0');

            for (String[] record : allRecords) {
                String value = record[colIndex];
                tempIndex.computeIfAbsent(value, k -> new StringBuilder(new String(zeros)));
            }

            int recordIndex = 0;
            for (String[] record : allRecords) {
                String value = record[colIndex];
                tempIndex.get(value).setCharAt(recordIndex, '1');
                recordIndex++;
            }

            for (String value : tempIndex.keySet()) {
                bitmapIndex.addValue(value, tempIndex.get(value).toString());
            }

            FileManager.storeTableIndex(tableName, colName, bitmapIndex);
        }

       
        trace.append(missing.size()).append(" records in pages: ").append(missingPages).append(".");
        table.addTrace(trace.toString());
        FileManager.storeTable(tableName, table);
    }
    public static void main(String []args) throws IOException 
    { 
     FileManager.reset(); 
     String[] cols = {"id","name","major","semester","gpa"}; 
     createTable("student", cols); 
     String[] r1 = {"1", "stud1", "CS", "5", "0.9"}; 
     insert("student", r1); 
      
     String[] r2 = {"2", "stud2", "BI", "7", "1.2"}; 
     insert("student", r2); 
      
     String[] r3 = {"3", "stud3", "CS", "2", "2.4"}; 
     insert("student", r3); 
      
     String[] r4 = {"4", "stud4", "CS", "9", "1.2"}; 
     insert("student", r4); 
      
     String[] r5 = {"5", "stud5", "BI", "4", "3.5"}; 
     insert("student", r5); 
      
     
     System.out.println("File Manager trace before deleting pages: "+FileManager.trace()); 
     String path = 
   FileManager.class.getResource("FileManager.class").toString(); 
        File directory = new File(path.substring(6,path.length()-17) + 
   File.separator 
          + "Tables//student" + File.separator); 
        File[] contents = directory.listFiles(); 
        int[] pageDel = {0,2}; 
   for(int i=0;i<pageDel.length;i++) 
   { 
   contents[pageDel[i]].delete(); 
   } 
  
   System.out.println("File Manager trace after deleting pages: "+FileManager.trace()); 
   ArrayList<String[]> tr = validateRecords("student"); 
   System.out.println("Missing records count: "+tr.size()); 
   recoverRecords("student", tr); 
   System.out.println("--------------------------------"); 
   System.out.println("Recovering the missing records."); 
   tr = validateRecords("student"); 
   System.out.println("Missing record count: "+tr.size()); 
   System.out.println("File Manager trace after recovering missing records: "+FileManager.trace()); 
   System.out.println("--------------------------------"); 
   System.out.println("Full trace of the table: "); 
   System.out.println(getFullTrace("student")); 
   } 
}
